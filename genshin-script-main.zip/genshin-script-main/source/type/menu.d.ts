export class MenuG extends KeyBinding {
  constructor()
  private asMap(): void
  private asMiniMenu(): void
  init(): void
  private isMenu(): boolean
}
