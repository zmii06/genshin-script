export class AliceG {
  private mapOnSwitch: Record<string, string>
  constructor()
  init(): void
  next(): void
  private prepare(): void
  private watch(): void
}
