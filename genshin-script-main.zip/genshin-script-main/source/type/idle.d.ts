export class IdleG extends KeyBinding {
  listKey: string[]
  private token: string
  constructor()
  private clearTimer(): void
  init(): void
  private main(): void
  setTimer(): void
}
