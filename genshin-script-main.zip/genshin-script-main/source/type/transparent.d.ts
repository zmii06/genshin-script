export class TransparentG {
  constructor()
  init(): void
  set(n: number): void
}
