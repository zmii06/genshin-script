type Name = 'impetuous winds'

export class BuffG {
  private list: Name[]
  constructor()
  has(name: Name): boolean
  pick(): void
}
