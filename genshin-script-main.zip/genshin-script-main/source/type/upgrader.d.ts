export class UpgraderG {
  private target: number
  constructor()
  check(): void
}
