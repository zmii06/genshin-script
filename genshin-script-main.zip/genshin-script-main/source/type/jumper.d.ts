export class JumperG extends KeyBinding {
  private flagIsNormal: boolean
  private isBreaking: boolean
  private tsJump: number
  constructor()
  private check(): void
  init(): void
  jump(): void
  private watch(): void
}
